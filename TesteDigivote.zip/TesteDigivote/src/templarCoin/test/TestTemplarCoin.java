/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.test;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import templarCoin.core.Eleicao;
import templarCoin.core.Transaction;

/**
 *
 * @author manso
 */
public class TestTemplarCoin {
    public static void main(String[] args) {
        try {
            //TemplarCoin coin  = new Eleicao();
            
            Eleicao coin  = Eleicao.load("tc.obj");
          
            
            
            coin.add(new Transaction("Maria", "João"));
            System.out.println(coin);            
            coin.save("tc.obj");
            
        } catch (Exception ex) {
            Logger.getLogger(TestTemplarCoin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
