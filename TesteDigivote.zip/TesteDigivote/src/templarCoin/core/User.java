/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.core;

import templarCoin.blockchain.BlockChain;

import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tom
 */
public class User {
    
    
    public static BlockChain userLedger;
    private static String userName;
    private static PublicKey publicKey;
    private static PrivateKey privateKey;
    private static int flag = 1;
    public static boolean hasVoted;
    public static boolean hasRegistered; 
    public static String userChain = "BlockChain/UsersBlockChain.obj";
    public static String[] nomes = {"João", "Maria", "José"};
    
    

    public User(String userName, PublicKey publicKey, PrivateKey privateKey, boolean hasVoted) {
        this.userName = userName;
        this.publicKey = publicKey;
        this.privateKey = privateKey;
        this.hasVoted = hasVoted;
    }
    
    
    
    public User() throws UnsupportedEncodingException, NoSuchAlgorithmException {
       userLedger = new BlockChain();
         File usersChain = new File("BlockChain/UsersBlockChain.obj");
        if(!usersChain.exists()){
             String names = String.join(" ,", nomes);
        userLedger.add(names, 3);
        try {
            userLedger.save(userChain);
        } catch (Exception ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }
    
    

    public static String getUserName() {
        return userName;
    }

    public static void setPublicKey(PublicKey publicKey) {
        User.publicKey = publicKey;
    }

    public static void setPrivateKey(PrivateKey privateKey) {
        User.privateKey = privateKey;
    }

    public static PublicKey getPublicKey() {
        return publicKey;
    }

    public static PrivateKey getPrivateKey() {
        return privateKey;
    }
    
    public static BlockChain getUserLedger() {
        return userLedger;
    }
    
    public static boolean existsInUserNames(String username) {

        for(String name : nomes) {
          if(name.equals(username)) {
            return true;
          }
        }

        return false;
    }
 
   

public static boolean canVote() {
    // Check if the vote file exists for the current user
    File voteFile = new File("CanVote/" + userName + "_vote.ser");
    if (voteFile.exists()) {
        return false; // User can't vote if the vote file exists
    } else {
        return !hasVoted; // User can vote if the vote file doesn't exist
    }
}

public static void addNamesBlock(){
       
       
}

public static boolean canRegister(String username){

  File registerFile = new File("canRegister/" + username + "_register.ser");

  if(!registerFile.exists()) {
      return false; // tratar exceção
  }else{
      return !hasRegistered;
  }

 

}


public static void save(String fileName) throws Exception {
        userLedger.save(fileName);
    }
     
     
    public static User load(String fileName) throws Exception {
        User tmp = new User();
        tmp.userLedger.load(fileName);
        return tmp;
    }

    public void add(Voto t) throws Exception {
       
            userLedger.add(t.toText(),3);
       
    }


    public static void vote() {
        hasVoted = true; // Mark the user as voted
    }

    public static void saveVotedState(String username) {
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("CanVote/" + username + "vote.ser"))) {
        oos.writeBoolean(hasVoted);
    } catch (IOException e) {
        // Proper error handling, e.g., log the error or throw a custom exception
        e.printStackTrace();
    }
}


    public static void loadVotedState(String username) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("CanVote/" + username + "vote.ser"))) {
            hasVoted = ois.readBoolean();
        } catch (IOException e) {
            // Proper error handling, e.g., log the error or throw a custom exception
            e.printStackTrace();
        }
    }
    
}
