/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 *
 * @author tom
 */
public class User {
    
    private static String userName;
    private PublicKey publicKey;
    private PrivateKey privateKey;
    private Key secretKey;
    private static int flag = 1;
    public static boolean hasVoted;

    public User(String userName, PublicKey publicKey, PrivateKey privateKey, Key secretKey, boolean hasVoted) {
        this.userName = userName;
        this.publicKey = publicKey;
        this.privateKey = privateKey;
        this.secretKey = secretKey;
        this.hasVoted = hasVoted;
    }

    public static String getUserName() {
        return userName;
    }
    
   

public static boolean canVote() {
    // Check if the vote file exists for the current user
    File voteFile = new File("CanVote/" + userName + "_vote.ser");
    if (voteFile.exists()) {
        return false; // User can't vote if the vote file exists
    } else {
        return !hasVoted; // User can vote if the vote file doesn't exist
    }
}



    public static void vote() {
        hasVoted = true; // Mark the user as voted
    }

    public static void saveVotedState(String username) {
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("CanVote/" + username + "vote.ser"))) {
        oos.writeBoolean(hasVoted);
    } catch (IOException e) {
        // Proper error handling, e.g., log the error or throw a custom exception
        e.printStackTrace();
    }
}


    public static void loadVotedState(String username) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("CanVote/" + username + "vote.ser"))) {
            hasVoted = ois.readBoolean();
        } catch (IOException e) {
            // Proper error handling, e.g., log the error or throw a custom exception
            e.printStackTrace();
        }
    }
    
}
