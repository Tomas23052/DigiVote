/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.core;

import templarCoin.blockchain.Block;
import templarCoin.blockchain.BlockChain;
import templarCoin.blockchain.MerkleTreeString;

import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author tom
 */
public class User {


    public static BlockChain userLedger;
    public static boolean hasVoted;
    public static boolean hasRegistered;
    public static String userChain = "BlockChain/UsersBlockChain.obj";
    public static String[] nomes = {"João", "Maria", "José"};
    private static String userName;
    private static PublicKey publicKey;
    private static PrivateKey privateKey;
    private static int flag = 1;


    public User(String userName, PublicKey publicKey, PrivateKey privateKey, boolean hasVoted) {
        this.userName = userName;
        this.publicKey = publicKey;
        this.privateKey = privateKey;
        this.hasVoted = hasVoted;
    }


    public User() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        userLedger = new BlockChain();
        File usersChain = new File("BlockChain/UsersBlockChain.obj");
        if (!usersChain.exists()) {
            String names = String.join(" ,", nomes);
            userLedger.add(names, 3);
            try {
                userLedger.save(userChain);
            } catch (Exception ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }


    public static String getUserName() {
        return userName;
    }

    public static PublicKey getPublicKey() {
        return publicKey;
    }

    public static void setPublicKey(PublicKey publicKey) {
        User.publicKey = publicKey;
    }

    public static PrivateKey getPrivateKey() {
        return privateKey;
    }

    public static void setPrivateKey(PrivateKey privateKey) {
        User.privateKey = privateKey;
    }

    public static BlockChain getUserLedger() {
        return userLedger;
    }

    public static boolean existsInUserNames(String username) {

        for (String name : nomes) {
            if (name.equals(username)) {
                return true;
            }
        }

        return false;
    }


    public static boolean canVote(String Name) throws Exception {
        MerkleTreeString tree = Eleicao.loadMerkleTree("MerkleTree/merkle.ser");
        if (tree != null) {
            List elements = tree.getElements();
            for (Object elem : elements) {
                Voto voto = (Voto) elem;
                System.out.println("From: " + voto.getFrom());
                if ((voto.getFrom().equals(Name))) {
                    return true;
                }
            }

        }
        return false;
    }


    public static boolean isUserRegistered(String username) {

        try {
            User userchain = User.load(userChain);
            BlockChain chain = userchain.getUserLedger();

            for (Block block : chain.getChain()) {
                String data = new String(block.getData());

                if (data.contains(username)) {
                    // User found in blockchain, already registered
                    return true;
                }
            }

        } catch (Exception e) {
            // Handle error loading/parsing blockchain
        }

        // User not found in blockchain
        return false;
    }


    public static void save(String fileName) throws Exception {
        userLedger.save(fileName);
    }


    public static User load(String fileName) throws Exception {
        User tmp = new User();
        tmp.userLedger.load(fileName);
        return tmp;
    }

    public static void vote() {
        hasVoted = true; // Mark the user as voted
    }



    public void add(Voto t) throws Exception {

        userLedger.add(t.toText(), 3);

    }

}
