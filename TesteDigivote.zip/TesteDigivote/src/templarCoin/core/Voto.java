/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.core;

import java.io.Serializable;
import java.util.ArrayList;
import templarCoin.blockchain.BlockChain;
import templarCoin.blockchain.MerkleTreeString;

/**
 *
 * @author tom
 */
public class Voto implements Serializable {
    
    private String eleitor;
    private static final long serialVersionUID = 1L;
    private String candidato; 
    public BlockChain secureLedger;
    

    public Voto(String eleitor, String candidato) {
        this.eleitor = eleitor;
        this.candidato = candidato;
    }

    public String getEleitor() {
        return eleitor;
    }

    public void setEleitor(String eleitor) {
        this.eleitor = eleitor;
    }

    public String getCandidato() {
        return candidato;
    }

    public void setCandidato(String candidato) {
        this.candidato = candidato;
    }
    
    

   
    
    
    
}
