//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//::                                                                         ::
//::     Antonio Manuel Rodrigues Manso                                      ::
//::                                                                         ::
//::     I N S T I T U T O    P O L I T E C N I C O   D E   T O M A R        ::
//::     Escola Superior de Tecnologia de Tomar                              ::
//::     e-mail: manso@ipt.pt                                                ::
//::     url   : http://orion.ipt.pt/~manso                                  ::
//::                                                                         ::
//::     This software was build with the purpose of investigate and         ::
//::     learning.                                                           ::
//::                                                                         ::
//::                                                               (c)2020   ::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//////////////////////////////////////////////////////////////////////////////
package templarCoin.core;

import templarCoin.blockchain.Block;
import templarCoin.blockchain.BlockChain;
import templarCoin.blockchain.MerkleTreeString;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Eleicao with Merkle Tree integration.
 */
public class Eleicao implements Serializable {

    private static final long serialVersionUID = 123;
    public static BlockChain secureLedger;
    public static String partyVotesF = "Votos/partyVotes.obj";

    public static Candidato[] candidates = new Candidato[0];
    private int difficulty = 4;

    public Eleicao() {


        secureLedger = new BlockChain();

    }

    public static BlockChain getSecureLedger() {
        return secureLedger;
    }

    public static boolean addCandidate(Candidato candidate) {
        // Check if the candidate with the same name already exists
        for (Candidato c : candidates) {
            if (c.getNome().equals(candidate.getNome())) {
                return false; // Candidate with the same name already exists
            }
        }

        // Add the new candidate to the array
        Candidato[] updatedCandidates = new Candidato[candidates.length + 1];
        System.arraycopy(candidates, 0, updatedCandidates, 0, candidates.length);
        updatedCandidates[candidates.length] = candidate;
        candidates = updatedCandidates;

        return true; // Candidate added successfully
    }

    public static boolean removeCandidate(String candidateName) {
        for (int i = 0; i < candidates.length; i++) {
            if (candidates[i].getNome().equals(candidateName)) {
                // Create a new array without the removed candidate
                Candidato[] updatedCandidates = new Candidato[candidates.length - 1];
                System.arraycopy(candidates, 0, updatedCandidates, 0, i);
                System.arraycopy(candidates, i + 1, updatedCandidates, i, candidates.length - i - 1);
                candidates = updatedCandidates;

                return true; // Candidate found and removed
            }
        }

        return false; // Candidate not found
    }

    public static void saveCandidates(String fileName) throws Exception {
        // Code to save the candidates list to the specified file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(candidates);
        }
    }

    public static void loadCandidates(String filename) throws Exception {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {

            Candidato[] loadedCandidates = (Candidato[]) ois.readObject();

            // Limpa o array existente
            candidates = new Candidato[0];

            // Adiciona os candidatos carregados
            for (Candidato c : loadedCandidates) {
                addCandidate(c);
            }

        } catch (IOException | ClassNotFoundException e) {
            // Tratamento de exceções
        }
    }

    public static String loadLedger(String fileName) throws IOException, ClassNotFoundException {

        String data;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
            data = (String) in.readObject();
        }

        return data;

    }

    public static void saveMerkleTree(MerkleTreeString tree, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(tree);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load the Merkle Tree from a file
    public static MerkleTreeString loadMerkleTree(String fileName) {
        MerkleTreeString tree = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            tree = (MerkleTreeString) ois.readObject();
        } catch (FileNotFoundException e) {
            // Handle the case where the file does not exist
            System.err.println("File not found: " + fileName);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return tree;
    }

    public static void loadPartyVotesFromFile(String fileName) {

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {

            Map<String, Integer> voteCounts = (Map<String, Integer>) ois.readObject();

            // Update candidate vote counts
            for (Candidato c : candidates) {
                c.setVotos(voteCounts.get(c.getNome()));
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public static Eleicao load(String fileName) throws Exception {
        Eleicao tmp = new Eleicao();
        tmp.secureLedger.load(fileName);
        return tmp;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public Candidato[] getCandidates() {
        return candidates;
    }

    public List<Voto> getLedger() {
        List<Voto> lst = new ArrayList<>();

        for (Block b : secureLedger.getChain()) {
            Voto voto = Voto.fromText(b.getData());
            lst.add(voto);
        }
        return lst;
    }

    @Override
    public String toString() {
        StringBuilder txt = new StringBuilder();
        for (Voto transaction : getLedger()) {
            txt.append(transaction.toString()).append("\n");
        }
        return txt.toString();
    }

    public void saveLedger(String fileName, String data) throws Exception {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void savePartyVotesToFile(String fileName) {

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {

            Map<String, Integer> voteCounts = new HashMap<>();

            for (Candidato c : candidates) {
                voteCounts.put(c.getNome(), c.getVotos());
            }

            oos.writeObject(voteCounts);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void vote(Candidato selected) {
        selected.addVoto();
    }

    public void save(String fileName) throws Exception {
        secureLedger.save(fileName);
    }

    public boolean isValid(Voto t) throws Exception {
        if (t.getFrom().trim().isEmpty()) {
            throw new Exception("From user is empty");
        }
        if (t.getTo().trim().isEmpty()) {
            throw new Exception("To user is empty");
        }
        return true;
    }

    public void add(Voto t) throws Exception {

        secureLedger.add(t.toText(), difficulty);
    }

    public List<String> getUsersBalance() {
        //get Users


        //get amount of users
        ArrayList<String> balance = new ArrayList<>();
        for (Candidato c : candidates) {
            balance.add(c.toString());
        }
        return balance;
    }
}
