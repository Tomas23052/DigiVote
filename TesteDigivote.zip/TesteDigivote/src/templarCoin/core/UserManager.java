/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.core;

/**
 *
 * @author tom
 */




import templarCoin.utils.SecurityUtils;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import javax.swing.JOptionPane;

public class UserManager {
    
   public static void createAdmin() throws Exception {

  // Admin credentials
  String adminUser = "admin";
  String adminPass = "adminpass";

  // Generate admin keys
  KeyPair adminKeys = SecurityUtils.generateRSAKeyPair(2048);
  
  // Get admin folder
  File adminFolder = new File(".admin");
  if(!adminFolder.exists()) {
    adminFolder.mkdir(); 
  }

  // Save public key
  String publicKeyFile = ".admin/" + adminUser + ".pub";
  SecurityUtils.saveKey(adminKeys.getPublic(), publicKeyFile);

  // Save private key
  String privateKeyFile = ".admin/" + adminUser + ".priv";
  byte[] encryptedPrivateKey = SecurityUtils.encrypt(adminKeys.getPrivate().getEncoded(), adminPass);
  try (FileOutputStream fos = new FileOutputStream(privateKeyFile)) {
    fos.write(encryptedPrivateKey); 
  }

  // Save signature 
  byte[] registrationData = (adminUser + adminPass).getBytes();
  byte[] signature = SecurityUtils.sign(registrationData, adminKeys.getPrivate());
  String signatureFile = ".admin/" + adminUser + ".sig";
  try (FileOutputStream fos = new FileOutputStream(signatureFile)) {
    fos.write(signature);
  }

}
   
   public static void authenticateAdmin(String adminUsername, String adminPassword) throws Exception {
    // Load the admin's public key
    PublicKey adminPublicKey = SecurityUtils.loadPublicKey(".admin/" + adminUsername + ".pub");

    // Load the encrypted private key
    byte[] encryptedAdminPrivateKey = Files.readAllBytes(Paths.get(".admin/" + adminUsername + ".priv"));
    PrivateKey adminPrivateKey = SecurityUtils.getPrivateKey(SecurityUtils.decrypt(encryptedAdminPrivateKey, adminPassword));

    // Load the signature
    byte[] adminSignature = Files.readAllBytes(Paths.get(".admin/" + adminUsername + ".sig"));

    // Combine the admin username and password
    byte[] adminRegistrationData = (adminUsername + adminPassword).getBytes();

    // Verify the admin's signature
    boolean isAdminSignatureValid = SecurityUtils.verifySign(adminRegistrationData, adminSignature, adminPublicKey);

    if (isAdminSignatureValid) {
        System.out.println("Admin authenticated successfully.");
    } else {
        System.out.println("Admin authentication failed. Invalid signature.");
    }
}

    
    public static void registerUser(String username, String password) throws Exception {
        
        
        Path publicKeyPath = Paths.get("Users/" + username + ".pubkey");
        if (Files.exists(publicKeyPath)) {
           throw new Exception(username + " already exists"); 
        }else{
        // Generate a key pair
        KeyPair keyPair = SecurityUtils.generateRSAKeyPair(2048);
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        // Save the public key
        String publicKeyFile ="Users/" +  username + ".pub";
        SecurityUtils.saveKey(publicKey, publicKeyFile);

        // Sign registration data
        byte[] registrationData = (username + password).getBytes();
        byte[] signature = SecurityUtils.sign(registrationData, privateKey);

        // Save the signature
        String signatureFile = "Users/" + username + ".sig";
        try (FileOutputStream fos = new FileOutputStream(signatureFile)) {
            fos.write(signature);
        }

        // Encrypt and save the private key
        String privateKeyFile = "Users/" + username + ".priv";
        byte[] encryptedPrivateKey = SecurityUtils.encrypt(privateKey.getEncoded(), password);
        try (FileOutputStream fos = new FileOutputStream(privateKeyFile)) {
            fos.write(encryptedPrivateKey);
        }

        // Generate and encrypt the symmetric key
        Key symKey = SecurityUtils.generateAESKey(128);
        byte[] encryptedSymKey = SecurityUtils.encrypt(symKey.getEncoded(), publicKey);

        // Save the encrypted symmetric key
        String symKeyFile = "Users/" + username + ".sim";
        try (FileOutputStream fos = new FileOutputStream(symKeyFile)) {
            fos.write(encryptedSymKey);
        }
      }
    }

    public static void authenticateUser(String username, String password) throws Exception {
        PublicKey publicKey = SecurityUtils.loadPublicKey("Users/" + username + ".pub");

        byte[] encryptedPrivateKey = Files.readAllBytes(Paths.get("Users/" + username + ".priv"));
        PrivateKey privateKey = SecurityUtils.getPrivateKey(SecurityUtils.decrypt(encryptedPrivateKey, password));

        byte[] encryptedSymKey = Files.readAllBytes(Paths.get("Users/" + username + ".sim"));
        Key symKey = SecurityUtils.getAESKey(SecurityUtils.decrypt(encryptedSymKey, privateKey));

        // Load the signature
        byte[] signature = Files.readAllBytes(Paths.get("Users/" + username + ".sig"));

        // Combine the username and password
        byte[] registrationData = (username + password).getBytes();

        // Verify the signature
        boolean isSignatureValid = SecurityUtils.verifySign(registrationData, signature, publicKey);

        if (isSignatureValid) {
            System.out.println("User authenticated successfully.");
        } else {
            System.out.println("Authentication failed. Invalid signature.");
        }
    }

    public static void main(String[] args) throws Exception {
        String username = "user";
        String password = "password123";

        // Register a new user
        registerUser(username, password);

        // Authenticate the user
        authenticateUser(username, password);
    }
}
