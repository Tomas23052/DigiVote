/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templarCoin.distributed;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import templarCoin.core.UserManager;



/**
 *
 * @author tom
 */
public class LoginRemoteObject extends UnicastRemoteObject implements LoginRemoteInterface{

    public LoginRemoteObject(int port) throws RemoteException{
        super(port);
    }
    
    @Override
    public void createAdmin() {
        try {
            UserManager.createAdmin();
            System.out.println("ADmin registado remotamente");

        } catch (Exception ex) {
            Logger.getLogger(LoginRemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void authenticateAdmin(String username, String password) { 
        try {
            UserManager.authenticateAdmin(username, password);
            System.out.println("Admin loggado remotamente");
        } catch (Exception ex) {
            Logger.getLogger(LoginRemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void registerUser(String username, String password) {
        try {
            UserManager.registerUser(username, password);
            
            System.out.println("User registado remotamente");
        } catch (Exception ex) {
            Logger.getLogger(LoginRemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void authenticateUser(String username, String password) {
        try {
            UserManager.authenticateUser(username, password);
            System.out.println("User loggado remotamente");
        } catch (Exception ex) {
            Logger.getLogger(LoginRemoteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
