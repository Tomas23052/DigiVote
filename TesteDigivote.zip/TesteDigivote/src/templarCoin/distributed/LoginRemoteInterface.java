/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package templarCoin.distributed;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author tom
 */
public interface LoginRemoteInterface extends Remote{
    public static String OBJECT_NAME = "RemoteLogin";
    
    public void createAdmin() throws RemoteException;
    
    public void authenticateAdmin(String username, String password) throws RemoteException;
    
    public void registerUser(String username, String password) throws RemoteException;
    
    public void authenticateUser(String username, String password) throws RemoteException;
    
}
