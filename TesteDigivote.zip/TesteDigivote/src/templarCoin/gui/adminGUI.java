/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package templarCoin.gui;

import templarCoin.blockchain.MerkleTreeString;
import templarCoin.core.Candidato;
import templarCoin.core.Eleicao;
import templarCoin.core.User;

import javax.swing.*;
import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

import static templarCoin.core.Eleicao.candidates;

/**
 *
 * @author tom
 */
public class adminGUI extends javax.swing.JFrame {
    
    Eleicao vote = new Eleicao();
    Candidato cand = new Candidato();
    User user = new User();
    public static String candidatos = "Votos/candidatos.obj";
    public static String merkleTree = "MerkleTree/merkle.ser";
    public static String partyVotesF = "Votos/partyVotes.obj";
    public static String totalVotes = "Votos/totalVotes.ser";   
    public static String ledger = "Ledger/ledger.obj";
    public static String fileChain = "BlockChain/Blockchain.obj";
    public static String candChain ="BlockChain/CandidatoBlockchain.obj";
    public static String userChain ="BlockChain/UsersBlockChain.obj";
    public static int status;


    /**
     * Creates new form adminGUI
     */
    public adminGUI() throws UnsupportedEncodingException, NoSuchAlgorithmException {
    initComponents();
    

    // Load the blockchain and candidates
    try {
        vote = Eleicao.load(fileChain);
        cand = Candidato.load(candChain);
        user = User.load(userChain);
        Eleicao.loadCandidates(candidatos);
    } catch (Exception ex) {
        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
    }

    // Initialize the candidate list
    Candidato[] candidates = Eleicao.candidates;

    txtLedger.setText(vote.toString());
//        try {
//            txtLedger.setText(Eleicao.loadLedger(ledger));
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
//        }


////     Load the ledger
//    try {
//        
////        txtLedger.setText(Eleicao.loadLedger(ledger));
//    } catch (IOException | ClassNotFoundException ex) {
//        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
//    }
    
    Eleicao.loadPartyVotesFromFile(partyVotesF);
    // Add this code where you want to display the candidate vote counts
    updateCandidateList();
    
    
    
   
    // Update the candidate list and Merkle Tree display
    MerkleTreeString loadedTree = vote.loadMerkleTree(merkleTree);
    if (loadedTree != null) {
        txtMerkleTree.setText(loadedTree.toString());
    } else {
        txtMerkleTree.setText("Merkle Tree not found or empty.");
    }
  

    txtCBlockChain.setText(cand.getCandidatosledger().toString());
    txtBlockChain.setText(vote.getSecureLedger().toString());
    txtUsers.setText(user.getUserLedger().toString());
    
    loadTotalVotos();
    if(status == 0){
        lstUsers.setVisible(false);
        txtWinner.setVisible(false);
        btnAdd.setVisible(false);
        btnRemove.setVisible(false);
        cPartido.setVisible(false);
        txtPartido.setVisible(false);
        jLabel2.setVisible(false);
        jLabel3.setVisible(false);
    }else{
        lstUsers.setVisible(true);
        mostraVencedor();
        txtWinner.setVisible(true);
        btnAdd.setVisible(true);
        btnRemove.setVisible(true);
        cPartido.setVisible(true);
        txtPartido.setVisible(true);
        jLabel2.setVisible(true);
        jLabel3.setVisible(true);
    }

    for (Candidato c : candidates) {
        cPartido.addItem(c.getNome());
    }

    setLocationRelativeTo(null);
}

    
    
   // In adminGUI

private void updateCandidateList() {

  DefaultListModel model = new DefaultListModel();
            model.addAll(vote.getUsersBalance());
            lstUsers.setModel(model);
}

    private void saveTotalVotos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(".totalvotos.ser"))) {
      oos.writeInt(status);
    } catch (IOException e) {
      e.printStackTrace();
    }
}

private void loadTotalVotos() {
  try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(".totalvotos.ser"))) {
    status = ois.readInt(); // Read an integer

  } catch (IOException e) {
    e.printStackTrace();
  }
}

private void mostraVencedor(){
    int maxVotes = 0;
    Candidato vencedor = null;
    
    for(Candidato c : candidates){
        if(c.getVotos() > maxVotes){
            maxVotes = c.getVotos();
            vencedor = c;
        }
    }
    
    txtWinner.setText("O vencedor é a " + vencedor.getNome() + " com " + vencedor.getVotos() + " votos");
}

private void deleteFiles(){
  File fileToDelete = new File(candidatos);
  fileToDelete.delete();

  fileToDelete = new File(merkleTree); 
  fileToDelete.delete();

  fileToDelete = new File(partyVotesF);
  fileToDelete.delete();

  fileToDelete = new File(totalVotes);
  fileToDelete.delete();

  fileToDelete = new File(ledger);
  fileToDelete.delete();

  fileToDelete = new File(fileChain);
  fileToDelete.delete();

  fileToDelete = new File(candChain);
  fileToDelete.delete();

  fileToDelete = new File(userChain);
  fileToDelete.delete();
  
  fileToDelete = new File(".totalvotos.ser");
  fileToDelete.delete();
  
  fileToDelete = new File(".votos.ser");
  fileToDelete.delete();
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtPartido = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnRemove = new javax.swing.JButton();
        cPartido = new javax.swing.JComboBox<>();
        btnAdd = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        scroll = new javax.swing.JScrollPane();
        lstUsers = new javax.swing.JList<>();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        s = new javax.swing.JScrollPane();
        txtBlockChain = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtCBlockChain = new javax.swing.JTextArea();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtUsers = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtLedger = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtMerkleTree = new javax.swing.JTextArea();
        txtWinner = new javax.swing.JLabel();
        eleicaoStart = new javax.swing.JButton();
        endEleicao = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("DigiVote Admin");

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Zona Admin");
        jLabel1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jLabel1ComponentResized(evt);
            }
        });

        jLabel2.setText("Remova um partido: ");

        btnRemove.setText("Remover");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        cPartido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cPartidoActionPerformed(evt);
            }
        });

        btnAdd.setText("Adicionar");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    btnAddActionPerformed(evt);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        jLabel3.setText("Adicione um novo Partido:");

        lstUsers.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        scroll.setViewportView(lstUsers);

        txtBlockChain.setColumns(20);
        txtBlockChain.setRows(5);
        s.setViewportView(txtBlockChain);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(s, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(s, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Votos", jPanel1);

        txtCBlockChain.setColumns(20);
        txtCBlockChain.setRows(5);
        jScrollPane1.setViewportView(txtCBlockChain);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Partidos", jPanel4);

        txtUsers.setColumns(20);
        txtUsers.setRows(5);
        jScrollPane4.setViewportView(txtUsers);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Users", jPanel5);

        txtLedger.setColumns(20);
        txtLedger.setRows(5);
        jScrollPane2.setViewportView(txtLedger);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Ledger", jPanel2);

        txtMerkleTree.setColumns(20);
        txtMerkleTree.setRows(5);
        jScrollPane3.setViewportView(txtMerkleTree);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("MerkleTree", jPanel3);

        txtWinner.setBorder(javax.swing.BorderFactory.createTitledBorder("Vencedor da eleição"));

        eleicaoStart.setText("Começar Eleição");
        eleicaoStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eleicaoStartActionPerformed(evt);
            }
        });

        endEleicao.setText("Acabar Eleição");
        endEleicao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endEleicaoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPartido, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                            .addComponent(cPartido, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(eleicaoStart, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                            .addComponent(endEleicao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(322, 322, 322)
                                .addComponent(scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 35, Short.MAX_VALUE)))
                .addGap(83, 83, 83))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtWinner, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(166, 166, 166))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtWinner, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPartido, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cPartido, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eleicaoStart, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(endEleicao, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jLabel1ComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1ComponentResized

    private void cPartidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cPartidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cPartidoActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) throws UnsupportedEncodingException, NoSuchAlgorithmException {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
     String nome = txtPartido.getText();
    Candidato c = new Candidato(nome, 0);
    Eleicao.addCandidate(c); // Add the new candidate to the list
    cPartido.addItem(nome);

    try {
        Eleicao.saveCandidates(candidatos); // Save the candidates list
    } catch (Exception ex) {
        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
    }

    Candidato.candidatosledger.add(nome, 4);
    
    try {
        vote.save(fileChain);
        cand.save(candChain);
        user.save(userChain);
    } catch (Exception ex) {
        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
    }
    
        try {
            cand = Candidato.load(candChain);
        } catch (Exception ex) {
            Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    txtCBlockChain.setText(cand.getCandidatosledger().toString());
    updateCandidateList(); // Call the method to update the list
    txtPartido.setText("");
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
    String selectedCandidate = cPartido.getSelectedItem().toString();
    
    
    
   for (int i = 0; i < candidates.length; i++) {
  if (candidates[i].getNome().equals(selectedCandidate)) {
    // Desloca os demais candidatos para preencher esta posição
    for (int j = i + 1; j < candidates.length; j++) {
      candidates[j-1] = candidates[j]; 
    }
    // Encurta o array    
    Candidato[] newCandidates = new Candidato[candidates.length-1];
    System.arraycopy(candidates, 0, newCandidates, 0, newCandidates.length);
    candidates = newCandidates;
    break;
  }
}

    // Remove the selected item from the combo box
    cPartido.removeItem(selectedCandidate);

    try {
        Eleicao.saveCandidates(candidatos); // Save the updated candidates list
    } catch (Exception ex) {
        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
    }

    try {
        vote.save(fileChain);
        cand.save(candChain);
        user.save(userChain);
    } catch (Exception ex) {
        Logger.getLogger(adminGUI.class.getName()).log(Level.SEVERE, null, ex);
    }
    updateCandidateList();

    }//GEN-LAST:event_btnRemoveActionPerformed

    private void eleicaoStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eleicaoStartActionPerformed
        // TODO add your handling code here:
        
        status = 0;
        saveTotalVotos();
        lstUsers.setVisible(false);
        txtWinner.setVisible(false);
        btnAdd.setVisible(false);
        btnRemove.setVisible(false);
        cPartido.setVisible(false);
        txtPartido.setVisible(false);
        jLabel2.setVisible(false);
        jLabel3.setVisible(false);
    }//GEN-LAST:event_eleicaoStartActionPerformed

    private void endEleicaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endEleicaoActionPerformed
        // TODO add your handling code here:
        status = 1; 
        saveTotalVotos();
        btnAdd.setVisible(true);
        btnRemove.setVisible(true);
        cPartido.setVisible(true);
        txtPartido.setVisible(true);
        lstUsers.setVisible(true);
        jLabel2.setVisible(true);
        jLabel3.setVisible(true);
        mostraVencedor();
        txtWinner.setVisible(true);
    }//GEN-LAST:event_endEleicaoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(adminGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(adminGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(adminGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(adminGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new adminGUI().setVisible(true);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnRemove;
    private javax.swing.JComboBox<String> cPartido;
    private javax.swing.JButton eleicaoStart;
    private javax.swing.JButton endEleicao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JList<String> lstUsers;
    private javax.swing.JScrollPane s;
    private javax.swing.JScrollPane scroll;
    private javax.swing.JTextArea txtBlockChain;
    private javax.swing.JTextArea txtCBlockChain;
    private javax.swing.JTextArea txtLedger;
    private javax.swing.JTextArea txtMerkleTree;
    private javax.swing.JTextField txtPartido;
    private javax.swing.JTextArea txtUsers;
    private javax.swing.JLabel txtWinner;
    // End of variables declaration//GEN-END:variables
}
