/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package templarCoin.gui;

import templarCoin.blockchain.Hash;
import templarCoin.blockchain.MerkleTreeString;
import templarCoin.core.Candidato;
import templarCoin.core.Eleicao;
import templarCoin.core.User;
import templarCoin.core.Voto;
import templarCoin.utils.SecurityUtils;

import javax.swing.*;
import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author tom
 */
public class EleicaoGUI extends javax.swing.JFrame {

    public static String fileChain = "BlockChain/Blockchain.obj";
    public static String merkleTree = "MerkleTree/merkle.ser";
    public static String partyVotes = "Votos/partyVotes.obj";
    public static String ledger = "Ledger/ledger.obj";
    public static String state = "Votos/estadoVoto.obj";
    public static String candidatos = "Votos/candidatos.obj";
    public static String candChain = "BlockChain/CandidatoBlockchain.obj";
    public static String userChain = "BlockChain/UsersBlockChain.obj";
    public static int status;
    private static String username;
    private static String userHash;
    public ArrayList<Voto> votos = new ArrayList<>();
    Eleicao vote = new Eleicao();
    Candidato cand = new Candidato();
    User u = new User();
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVotar;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane tpTransaction;
    private javax.swing.JTextField txtFrom;
    private javax.swing.JTextArea txtLedger;
//GEN-LAST:event_btnVotarActionPerformed
    private javax.swing.JLabel txtNonce;
    private javax.swing.JComboBox<String> txtPartido;
    /**
     * Creates new form EleicaoGUI1
     */
    public EleicaoGUI(String username) throws UnsupportedEncodingException, NoSuchAlgorithmException {

        initComponents();
        txtLedger.setVisible(false);
        this.username = username;
        try {
            Eleicao.loadCandidates(candidatos);
        } catch (Exception ex) {
            Logger.getLogger(EleicaoGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        Candidato[] candidates = vote.getCandidates();
        try {
            vote = Eleicao.load(fileChain);
            cand = Candidato.load(candChain);
            u = User.load(userChain);
        } catch (Exception e) {
        }

        try {

            txtLedger.setText(Eleicao.loadLedger(ledger));

            txtNonce.setVisible(false);

        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        Eleicao.loadPartyVotesFromFile(partyVotes);

//        txtLeger.setText(vote.toString());
        for (Candidato c : candidates) {
            txtPartido.addItem(c.getNome());
        }

        loadVotos();
        loadTotalVotos();
        if (votos.size() >= 10) {
            votos.clear();
        }

//        User.loadVotedState(username);


        txtFrom.setText(username);
        setLocationRelativeTo(null);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EleicaoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new EleicaoGUI(username).setVisible(true);
                } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    private void saveVotos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(".votos.ser"))) {
            oos.writeObject(votos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load votos
    private void loadVotos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(".votos.ser"))) {
            votos = (ArrayList<Voto>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Load votos
    private void loadTotalVotos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(".totalvotos.ser"))) {
            status = (int) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        tpTransaction = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        txtFrom = new javax.swing.JTextField();
        txtPartido = new javax.swing.JComboBox<>();
        btnVotar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtLedger = new javax.swing.JTextArea();
        txtNonce = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Eleição DigiVote");

        tpTransaction.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tpTransactionStateChanged(evt);
            }
        });

        txtFrom.setBorder(javax.swing.BorderFactory.createTitledBorder("Eleitor"));
        txtFrom.setEnabled(false);

        txtPartido.setBorder(javax.swing.BorderFactory.createTitledBorder("Partido"));

        btnVotar.setText("Votar");
        btnVotar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    btnVotarActionPerformed(evt);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        txtLedger.setColumns(20);
        txtLedger.setRows(5);
        jScrollPane2.setViewportView(txtLedger);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtFrom)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnVotar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtPartido, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGap(49, 49, 49)
                                                .addComponent(txtNonce, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(31, 31, 31)
                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 5, Short.MAX_VALUE)))
                                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(txtFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPartido, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnVotar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGap(42, 42, 42)
                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(txtNonce, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(24, Short.MAX_VALUE))
        );

        tpTransaction.addTab("Votar", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(tpTransaction, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(tpTransaction)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tpTransactionStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tpTransactionStateChanged

    }//GEN-LAST:event_tpTransactionStateChanged

    private void btnVotarActionPerformed(java.awt.event.ActionEvent evt) throws Exception {//GEN-FIRST:event_btnVotarActionPerformed
        // TODO add your handling code here

//        PublicKey UserpublicKey = SecurityUtils.loadPublicKey("Users/" + username + ".pub");
//        byte [] name = txtFrom.getText().getBytes();
//        byte [] ename = SecurityUtils.encrypt(name, UserpublicKey);
//        String Name = Base64.getEncoder().encodeToString(ename);
        String Name = Hash.getHash(txtFrom.getText());
        if (!User.canVote(Name)) {
            ImageIcon img = new ImageIcon(getClass().getClassLoader().getResource("templarCoin/multimedia/loading.gif"));
            txtNonce.setIcon(img);
            txtNonce.setHorizontalAlignment(JLabel.CENTER);
            txtNonce.setVerticalAlignment(JLabel.CENTER);
            txtNonce.setBounds(0, 0, 5, 5);
            txtNonce.setVisible(true);

            // Crie um SwingWorker para realizar o processamento do voto em segundo plano
            SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                @Override
                protected Void doInBackground() throws Exception {
                    PublicKey adminPublicKey = SecurityUtils.loadPublicKey(".admin/" + "admin" + ".pub");
                    byte[] partido = txtPartido.getSelectedItem().toString().getBytes();
                    byte[] epartido = SecurityUtils.encrypt(partido, adminPublicKey);
                    Voto v = new Voto(Name, Base64.getEncoder().encodeToString(epartido));
                    v.setFrom(Name);

                    if (votos.size() <= 1) {
                        try {
                            votos.add(v);
                            txtLedger.append(Name + " -> " + Base64.getEncoder().encodeToString(epartido) + "\n");
                            saveVotos();
                            vote.saveLedger(ledger, txtLedger.getText());
                            User.vote();
                            User.saveVotedState(username);
                            Candidato[] candidates = vote.getCandidates();
                            String partidoSelecionado = (String) txtPartido.getSelectedItem();
                            Candidato selected = null;
                            for (Candidato c : candidates) {
                                if (c.getNome().equals(partidoSelecionado)) {
                                    selected = c;
                                    break;
                                }
                            }
                            if (selected != null) {
                                selected.addVoto();
                            }
                            vote.savePartyVotesToFile(partyVotes);

                            if (votos.size() < 1) {
                                return null;
                            }

                            MerkleTreeString tree = new MerkleTreeString(votos);

                            vote.secureLedger.add(tree.getRoot(), 6);

                            // Mostrar uma mensagem após o processamento ser concluído

                            vote.saveMerkleTree(tree, merkleTree);

                            try {
                                vote.save(fileChain);
                                u.save(userChain);
                                cand.save(candChain);
                            } catch (Exception ex) {
                                Logger.getLogger(EleicaoGUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(EleicaoGUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                    return null;
                }

                @Override
                protected void done() {
                    // Após a conclusão do processamento, oculte a animação de carregamento
                    txtNonce.setVisible(false);
                    JOptionPane.showMessageDialog(null, "O voto de " + username + " na " + txtPartido.getSelectedItem().toString() + " foi registado com sucesso!", "Voto efetuado com sucesso", JOptionPane.INFORMATION_MESSAGE);

                }
            };

            // Iniciar o SwingWorker para realizar o processamento do voto em segundo plano
            worker.execute();
        } else {
            JOptionPane.showMessageDialog(null, txtFrom.getText() + " não pode votar mais que uma vez, por questões legais e morais.", "Erro de dupla votação", JOptionPane.ERROR_MESSAGE);
        }
    }
    // End of variables declaration//GEN-END:variables
}
