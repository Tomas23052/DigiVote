package templarCoin.blockchain;

import javax.swing.*;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.atomic.AtomicInteger;

public class Miner extends SwingWorker<Integer, Void> {
    private final String data;
    private final int difficulty;

    public Miner(String data, int difficulty) {
        this.data = data;
        this.difficulty = difficulty;
    }

    @Override
    protected Integer doInBackground() {
        int cores = Runtime.getRuntime().availableProcessors();
        AtomicInteger nonce = new AtomicInteger(0);
        AtomicInteger count = new AtomicInteger(0);
        Thread[] threads = new Thread[cores];

        for (int i = 0; i < cores; i++) {
            threads[i] = new Thread(() -> {
                String end = "0".repeat(difficulty);
                int testNonce;
                while (nonce.get() == 0 && !isCancelled()) {
                    testNonce = count.getAndIncrement();
                    String hash = null;
                    try {
                        hash = Hash.getHash(data + testNonce);
                    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
                        throw new RuntimeException(e);
                    }
                    if (hash.endsWith(end)) {
                        System.out.println("Hash: " + hash);
                        nonce.set(testNonce);
                        System.out.println("Nonce: " + nonce.get());
                        cancel(true); // Cancel the SwingWorker if a solution is found.
                        return;
                    }
                }
            });
        }

        for (Thread thread : threads) thread.start();

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException ignored) {
            }
        }

        return nonce.get();
    }

}
